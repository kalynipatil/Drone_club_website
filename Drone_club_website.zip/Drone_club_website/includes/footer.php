<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Team Third Axis</title>

    <!-- bootstrap link -->
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"> -->

    <!-- stylesheet -->
    <link rel="stylesheet" href="styles.css" />
    <!-- Font Awesome -->
    <script src="https://kit.fontawesome.com/4e3bb66a2c.js"></script>
    <!-- font -->
    <link
      href="https://fonts.googleapis.com/css2?family=Merriweather:wght@700&display=swap"
      rel="stylesheet"
    />
    <!-- style sheet -->
    <link
      href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css"
      rel="stylesheet"
    />
</head>
<body>
  
    <!-- Footer section -->
    <footer class="footer-distributed">
      <!-- footer left -->
      <div class="footer-left">
        <h3>
          <span style="color: white">Team </span>
          <span style="color: #c3352f">Third </span>
          <span style="color: white">Axis </span>
        </h3>

        <p class="footer-links">
          <a href="index.html">Home</a>
          |
          <a href="team.html">Our Team</a>
          |
          <a href="#">Blog</a>
          |
          <a href="gallery.html">Gallery</a>
          |
          <a href="contact.html">Contact Us</a>
        </p>
        <p class="footer-team-name">teamthirdaxis © 2022</p>
      </div>

      <!-- footer center -->
      <div class="footer-center">
        <div>
          <a
            href=" https://www.google.com/maps/place/Government+College+of+Engineering/@21.0028317,75.5465882,17z/data=!3m1!4b1!4m6!3m5!1s0x3bd90fc9945a06b3:0x2adbed89161ccac2!8m2!3d21.0028267!4d75.5487769!16s%2Fg%2F1234vp9f_"
          >
            <i class="fa fa-map-marker"></i
          ></a>
          <p>
            <span>Government College Of Engineering,</span>
            <span style="position: relative; text-align: left"
              >Jalgaon- 425001</span
            >
            <span style="position: relative; text-align: left"
              >Maharashtra , India</span
            >
          </p>
        </div>

        <div>
          <a href="mailto:teamthirdaxis@gcoej.ac.in">
            <i class="fa fa-envelope"></i
          ></a>
          <p>
            <span style="position: relative; text-align: left"
              >teamthirdaxis@gcoej.ac.in</span
            >
            <span> </span>
          </p>
        </div>
      </div>

      <!-- footer right -->
      <div class="footer-right">
        <p class="footer-team-about">
          <span>About Us</span>
          <br />
          We participate in SAE Collegiate competitions like SAE Aerothon and
          SAE Aero Design.
        </p>
        <div class="footer-icons">
          <a
            href="https://www.facebook.com/profile.php?id=100090532036520&mibextid=ZbWKwL"
            ><i class="social-icon fab fa-facebook-f" aria-hidden="true"></i
          ></a>
          <a href=""
            ><i class="social-icon fab fa-twitter" aria-hidden="true"></i
          ></a>
          <a href="https://instagram.com/team_third_axis?igshid=ZDdkNTZiNTM="
            ><i class="social-icon fab fa-instagram" aria-hidden="true"></i
          ></a>
          <a href="https://www.linkedin.com/in/team-third-axis-539510269"
            ><i class="social-icon fab fa-linkedin" aria-hidden="true"></i
          ></a>
          <a href=""><i class="fa-brands fa-youtube" aria-hidden="true"></i></a>
        </div>
      </div>
    </footer>

    <!-- scripts -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="script.js" charset="utf-8"></script>
    <!-- end of body -->
  </body>
</html>
