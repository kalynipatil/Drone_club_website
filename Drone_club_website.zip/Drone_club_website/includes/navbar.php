<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Team Third Axis</title>

    <!-- bootstrap link -->
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"> -->

    <!-- stylesheet -->
    <!-- <link rel="stylesheet" href="styles.css" /> -->
    <!-- Font Awesome -->
    <script src="https://kit.fontawesome.com/4e3bb66a2c.js"></script>
    <!-- font -->
    <link
      href="https://fonts.googleapis.com/css2?family=Merriweather:wght@700&display=swap"
      rel="stylesheet"
    />
    <!-- style sheet -->
    <link
      href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css"
      rel="stylesheet"
    />
   </head>
<style>
*{
  margin: 0;
  padding: 0;
  box-sizing:border-box;
  font-family: 'Merriweather', serif;
}

body
{
  margin: 0;
  background-size: cover;
  background-color: #0d0d0d;
  background-repeat: no-repeat;
}
 /* -------------------------------------------------------- Home page section ---------------------------------------------------------------*/

 /* header section */
.header2{
  top: 0;
  position: fixed;
  left: 0;
  width: 100%;
  padding: 7px 50px;
/* background: rgb(0, 26, 26); */
  background: rgba(255,255,255,.1);
  display:flex;
  justify-content:space-between ;
  align-items: center;
  backdrop-filter: blur(10px);
  z-index: 100;

}
/* header effect */
.header2::before
{
  content: " ";
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4),transparent);
  transition : 0.2s;
}
.header2:hover::before{
  left: 100%;
}
/* logo */
.logo{
   cursor: default;
}

/* navbar effect */

.navbar a{
  font-size: 18px;
  color:#fff;
  margin-left:35px;
}
.navbar a:link {
            text-decoration: none;
}
.navbar a:hover{
  color: #C3352F;
}
#nav2{
  margin: 0 !important;
/* margin-top: 10px !important; */
  padding: 11px !important;}

/* menu */
#menu-icon{
  font-size: 36px;
  color: #fff;
  display:none;

}

/* breakpoints */
@media (max-width :992px) {
   .header{
     padding: 1.25rem 4% ;
   }
}
@media (max-width :768px){
  #menu-icon{
    display: block;
}
.navbar{
    position: fixed;
    top: 100%;
    left: 0;
    width: 100%;
    padding: -5rem 4%;
    display: none;
}
.navbar.active{
      display: block;
}
.navbar a {
    display: block;
    margin: 1.5rem 0 0 2.5rem;
}
.nav-bg{
    position: fixed;
    top: 11.8%;
    left: 0;
    width: 100%;
    height: 295px;
    background: rgba(255, 255, 255, 0.1);
    z-index: 99;
    display: none;
}
.nav-bg.active{
   display: block;

 }
}

</style>
<body>
<!--Navigation bar -->
 <header class="header2">
  <img src="images/logo-clg.png" width="90px" height="60px" alt="logo" class="logo">
  <i class='bx bx-menu' id= "menu-icon" ></i>
  <nav class="navbar" id="nav2">
       <a href="index.html">Home</a>
       <a href="team.html">Our Team</a>
       <a href="#">Blog</a>
       <a href="gallery.html">Gallery</a>
       <a href="contact.html">Contact us</a>
       </nav>
 </header>
 
    <!-- scripts -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="script.js" charset="utf-8"></script>
    <!-- end of body -->
</body>
</html>